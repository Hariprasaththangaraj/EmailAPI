package com.server.main.user.exception;

public class Constant {

	public static final String MESSAGE_STRING = "Email ID Should not be Empty/NULL";

	private Constant() {

	}
}
