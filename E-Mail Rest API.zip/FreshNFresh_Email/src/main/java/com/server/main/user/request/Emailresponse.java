package com.server.main.user.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Emailresponse {

		String message="Email Sent Successfully!!!!";

}
